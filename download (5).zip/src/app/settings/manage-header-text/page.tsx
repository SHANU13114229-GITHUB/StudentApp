// src/app/settings/manage-header-text/page.tsx
"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Save, Text } from "lucide-react";
import { getUserProfile, updateUserProfile } from "@/services/user-profile";
import { Skeleton } from "@/components/ui/skeleton";

export default function ManageHeaderTextPage() {
  const [greeting, setGreeting] = useState("");
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    const profile = getUserProfile();
    setGreeting(profile.greetingText || "Good Morning");
    setName(profile.studentName || "SHANU VISHWAKARMA");
    setLoading(false);
  }, []);

  const handleSave = () => {
    updateUserProfile({ 
        greetingText: greeting,
        studentName: name
    });
    router.push("/");
  };

  if (loading) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-gray-100 p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-center text-2xl font-bold">
              Manage Header Text
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-8">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gray-100 p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-center text-2xl font-bold">
            Manage Header Text
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-8">
          <div className="space-y-4">
            <div className="space-y-2">
                <Label htmlFor="greeting-input">Greeting Text</Label>
                <Input
                    id="greeting-input"
                    value={greeting}
                    onChange={(e) => setGreeting(e.target.value)}
                    placeholder="e.g., Good Morning"
                />
            </div>
             <div className="space-y-2">
                <Label htmlFor="name-input">Student Name</Label>
                <Input
                    id="name-input"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g., SHANU VISHWAKARMA"
                />
            </div>
          </div>

          <Button onClick={handleSave} className="w-full">
            <Save className="mr-2 h-4 w-4" />
            Save and Go to Home
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
