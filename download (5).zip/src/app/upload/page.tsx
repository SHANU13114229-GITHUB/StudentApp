// src/app/upload/page.tsx
"use client";

import { useState, ChangeEvent, useEffect } from "react";
import Image from "next/image";
import { useRouter } from 'next/navigation';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Upload } from "lucide-react";
import { getUserProfile, updateUserProfile } from "@/services/user-profile";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";


export default function UploadImagePage() {
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [newImage, setNewImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const router = useRouter();

  useEffect(() => {
    const profile = getUserProfile();
    if (profile.collegeImage) {
      setImagePreview(profile.collegeImage);
    } else {
      const defaultImage = "/sheat-eng-mgm.png";
      setImagePreview(defaultImage);
    }
    setLoading(false);
  }, []);

  const handleImageChange = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setImagePreview(result);
        setNewImage(result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleUpload = () => {
    if (newImage) {
      updateUserProfile({ collegeImage: newImage });
      toast({
        title: "Success!",
        description: "Your showcase image has been updated.",
      });
      router.push("/");
    } else {
      // If no new image, just go back
      router.push("/");
    }
  };
  
  if (loading) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-gray-100 p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-center text-2xl font-bold">
              Upload Showcase Image
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <Skeleton className="h-10" />
            <Skeleton className="aspect-[21/9] w-full" />
            <Skeleton className="h-10" />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gray-100 p-4">
      <Card className="w-full max-w-lg">
        <CardHeader>
          <CardTitle className="text-center text-2xl font-bold">
            Upload Showcase Image
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <label htmlFor="image-upload" className="font-medium">
              Choose an image
            </label>
            <Input
              id="image-upload"
              type="file"
              accept="image/*"
              onChange={handleImageChange}
            />
          </div>

          {imagePreview && (
            <div className="relative aspect-video w-full overflow-hidden rounded-md border">
              <Image
                src={imagePreview}
                alt="Selected image preview"
                fill
                className="object-cover"
              />
            </div>
          )}

          <Button
            onClick={handleUpload}
            className="w-full"
          >
            <Upload className="mr-2 h-4 w-4" />
            Save and Go to Home
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
