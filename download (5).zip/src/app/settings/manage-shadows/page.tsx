// src/app/settings/manage-shadows/page.tsx
"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Save, Paintbrush } from "lucide-react";
import { getUserProfile, updateUserProfile } from "@/services/user-profile";
import { Skeleton } from "@/components/ui/skeleton";

const shadowLevels = ["shadow-none", "shadow-sm", "shadow", "shadow-md", "shadow-lg", "shadow-xl", "shadow-2xl"];
const shadowLabels = ["None", "Small", "Regular", "Medium", "Large", "Extra Large", "2x Large"];

export default function ManageShadowsPage() {
  const [shadowIndex, setShadowIndex] = useState(4); // Default to 'shadow-lg'
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    const profile = getUserProfile();
    const currentShadow = profile.blockShadow || "shadow-lg";
    const index = shadowLevels.indexOf(currentShadow);
    setShadowIndex(index !== -1 ? index : 4);
    setLoading(false);
  }, []);

  const handleSliderChange = (value: number[]) => {
    setShadowIndex(value[0]);
  };

  const handleSave = () => {
    updateUserProfile({ blockShadow: shadowLevels[shadowIndex] });
    router.push("/");
  };

  if (loading) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-gray-100 p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-center text-2xl font-bold">
              Manage Block Shadows
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-8">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-24 w-full" />
            <Skeleton className="h-10 w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gray-100 p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-center text-2xl font-bold">
            Manage Block Shadows
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-8">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Paintbrush className="h-5 w-5" />
                <label htmlFor="shadow-slider" className="font-medium">
                  Shadow Intensity
                </label>
              </div>
              <span className="font-bold text-lg text-primary">{shadowLabels[shadowIndex]}</span>
            </div>
            <Slider
              id="shadow-slider"
              min={0}
              max={shadowLevels.length - 1}
              step={1}
              value={[shadowIndex]}
              onValueChange={handleSliderChange}
            />
          </div>
          
          <div className="flex justify-center">
            <div className={`w-48 h-24 rounded-lg bg-card border flex items-center justify-center text-muted-foreground ${shadowLevels[shadowIndex]}`}>
                Preview
            </div>
          </div>

          <Button onClick={handleSave} className="w-full">
            <Save className="mr-2 h-4 w-4" />
            Save and Go to Home
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
