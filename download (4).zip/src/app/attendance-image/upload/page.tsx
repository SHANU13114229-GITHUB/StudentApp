// src/app/attendance-image/upload/page.tsx
"use client";

import { useState, ChangeEvent, useEffect } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Upload, UserCheck, Save } from "lucide-react";
import { getUserProfile, updateUserProfile } from "@/services/user-profile";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";

export default function UploadAttendanceImagePage() {
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [newImage, setNewImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const { toast } = useToast();

  useEffect(() => {
    const profile = getUserProfile();
    setImagePreview(profile.attendanceImage || null);
    setLoading(false);
  }, []);

  const handleImageChange = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setImagePreview(result);
        setNewImage(result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    if (newImage) {
      updateUserProfile({ attendanceImage: newImage });
    }
    toast({
        title: "Success!",
        description: "Your attendance image has been saved.",
    });
    router.push("/attendance-image");
  };
  
  const triggerFileInput = () => {
    document.getElementById('image-upload')?.click();
  }

  if (loading) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-gray-100 p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-center text-2xl font-bold">
                Upload Attendance Image
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <Skeleton className="aspect-video w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
     <div className="flex min-h-screen flex-col items-center justify-center bg-gray-100 p-4">
        <Card className="w-full max-w-md">
            <CardHeader>
                <CardTitle className="text-center text-2xl font-bold">
                    Upload Attendance Image
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <div className="relative mx-auto rounded-lg border-2 border-dashed bg-gray-200 flex items-center justify-center aspect-video w-full">
                {imagePreview ? (
                    <Image
                    src={imagePreview}
                    alt="Attendance Image Preview"
                    fill
                    className="object-contain p-2"
                    />
                ) : (
                    <div className="flex flex-col items-center text-gray-500">
                        <UserCheck className="h-16 w-16" />
                        <p>No image uploaded</p>
                    </div>
                )}
                </div>

                <Input
                    id="image-upload"
                    type="file"
                    accept="image/*"
                    onChange={handleImageChange}
                    className="hidden"
                />
                
                <Button
                    onClick={triggerFileInput}
                    variant="outline"
                    className="w-full"
                >
                    <Upload className="mr-2 h-4 w-4" />
                    {imagePreview ? "Change Image" : "Upload Image"}
                </Button>
                
                <Button
                    onClick={handleSave}
                    className="w-full h-12 text-lg"
                    disabled={!newImage && !imagePreview}
                >
                    <Save className="mr-2 h-5 w-5" />
                    Save and View
                </Button>

            </CardContent>
        </Card>
    </div>
  );
}
