"use client";

import { useState, useRef, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Send, User, Bot, Loader2, ImagePlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
  SheetFooter,
} from "@/components/ui/sheet";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem } from "@/components/ui/form";
import { ScrollArea } from "@/components/ui/scroll-area";
import { chatBotSupport } from "@/ai/flows/chatbot-support";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { getUserProfile } from "@/services/user-profile";

const formSchema = z.object({
  query: z.string().min(1, "Message cannot be empty"),
});

type Message = {
  role: "user" | "bot";
  content: string;
};

const initialMessages: Message[] = [
  {
    role: "bot",
    content:
      "Hello! I am the SHEAT Info Hub assistant. How can I help you today with timetables or FAQs?",
  },
];

export default function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [chatbotIcon, setChatbotIcon] = useState<string | null>(null);
  const [chatbotIconSize, setChatbotIconSize] = useState(100);

  const fetchProfile = () => {
    const profile = getUserProfile();
    if (profile.chatbotIcon) setChatbotIcon(profile.chatbotIcon);
    if (profile.chatbotIconSize) setChatbotIconSize(profile.chatbotIconSize);
  };

  useEffect(() => {
    fetchProfile();
    // Listen for changes from other tabs/windows
    window.addEventListener('storage', fetchProfile);
    return () => {
      window.removeEventListener('storage', fetchProfile);
    };
  }, []);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      query: "",
    },
  });

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true);
    const userMessage = values.query;
    setMessages((prev) => [...prev, { role: "user", content: userMessage }]);
    form.reset();

    try {
      const result = await chatBotSupport({ query: userMessage });
      setMessages((prev) => [...prev, { role: "bot", content: result.answer }]);
    } catch (error) {
      console.error("Chatbot error:", error);
      toast({
        variant: "destructive",
        title: "An error occurred",
        description: "Failed to get a response from the chatbot.",
      });
      setMessages((prev) => [
        ...prev,
        {
          role: "bot",
          content:
            "Sorry, I'm having trouble connecting. Please try again later.",
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    if (isOpen) {
      setTimeout(
        () => messagesEndRef.current?.scrollIntoView({ behavior: "smooth" }),
        100
      );
    }
  }, [messages, isLoading, isOpen]);

  // Reset chat when sheet is closed
  useEffect(() => {
    if (!isOpen) {
      // give it time to close before resetting
      setTimeout(() => {
        setMessages(initialMessages);
      }, 500);
    }
  }, [isOpen]);

  const iconStyle = {
    width: `${56 * (chatbotIconSize / 100)}px`,
    height: `${56 * (chatbotIconSize / 100)}px`,
  };


  return (
    <>
      <Sheet open={isOpen} onOpenChange={setIsOpen}>
        <SheetTrigger asChild>
          <Button
            style={iconStyle}
            className="fixed bottom-20 right-4 rounded-full bg-primary text-primary-foreground shadow-lg hover:bg-primary/90 z-40 p-0 overflow-hidden transition-all"
            size="icon"
          >
            {chatbotIcon ? (
              <Image src={chatbotIcon} alt="Chatbot Icon" fill className="object-cover" />
            ) : (
              <Bot className="h-1/2 w-1/2" />
            )}
            <span className="sr-only">Open Chat</span>
          </Button>
        </SheetTrigger>
        <SheetContent side="bottom" className="h-[85vh] flex flex-col p-0">
          <SheetHeader className="p-4 border-b flex flex-row justify-between items-center">
            <SheetTitle>SHEAT Support Assistant</SheetTitle>
            <Link href="/upload-chatbot-icon">
              <Button variant="outline" size="sm">
                <ImagePlus className="mr-2 h-4 w-4" />
                Change Icon
              </Button>
            </Link>
          </SheetHeader>
          <ScrollArea className="flex-grow">
            <div className="space-y-6 p-4">
              {messages.map((message, index) => (
                <div
                  key={index}
                  className={`flex items-start gap-3 text-sm ${
                    message.role === "bot" ? "justify-start" : "justify-end"
                  }`}
                >
                  {message.role === "bot" && (
                     <Avatar className="w-8 h-8 border-2 border-primary overflow-hidden">
                       {chatbotIcon ? (
                         <Image src={chatbotIcon} alt="Chatbot Icon" fill className="object-cover" />
                       ) : (
                        <AvatarFallback className="bg-primary text-primary-foreground">
                          <Bot size={18} />
                        </AvatarFallback>
                       )}
                    </Avatar>
                  )}
                  <div
                    className={`rounded-lg px-4 py-2 max-w-[80%] whitespace-pre-wrap ${
                      message.role === "bot"
                        ? "bg-secondary text-secondary-foreground"
                        : "bg-primary text-primary-foreground"
                    }`}
                  >
                    {message.content}
                  </div>
                  {message.role === "user" && (
                    <Avatar className="w-8 h-8">
                      <AvatarFallback className="bg-muted">
                        <User size={18} />
                      </AvatarFallback>
                    </Avatar>
                  )}
                </div>
              ))}
              {isLoading && (
                <div className="flex items-start gap-3 justify-start">
                   <Avatar className="w-8 h-8 border-2 border-primary overflow-hidden">
                       {chatbotIcon ? (
                         <Image src={chatbotIcon} alt="Chatbot Icon" fill className="object-cover" />
                       ) : (
                        <AvatarFallback className="bg-primary text-primary-foreground">
                          <Bot size={18} />
                        </AvatarFallback>
                       )}
                    </Avatar>
                  <div className="rounded-lg px-4 py-2 bg-secondary text-secondary-foreground">
                    <Loader2 className="h-5 w-5 animate-spin" />
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          </ScrollArea>
          <SheetFooter className="p-4 border-t bg-background">
            <Form {...form}>
              <form
                onSubmit={form.handleSubmit(onSubmit)}
                className="flex w-full items-center space-x-2"
              >
                <FormField
                  control={form.control}
                  name="query"
                  render={({ field }) => (
                    <FormItem className="flex-grow">
                      <FormControl>
                        <Input
                          placeholder="Ask about timetables, FAQs..."
                          {...field}
                          autoComplete="off"
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <Button
                  type="submit"
                  size="icon"
                  disabled={isLoading || !form.formState.isValid}
                >
                  <Send className="h-5 w-5" />
                </Button>
              </form>
            </Form>
          </SheetFooter>
        </SheetContent>
      </Sheet>
    </>
  );
}
