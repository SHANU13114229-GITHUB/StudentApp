// src/components/dashboard/college-showcase.tsx
"use client";

import Image from "next/image";
import Link from "next/link";
import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { getUserProfile } from "@/services/user-profile";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import { cn } from "@/lib/utils";

export default function CollegeShowcase() {
  const [image, setImage] = useState<string | null>(null);
  const [height, setHeight] = useState(200);
  const [width, setWidth] = useState(100);
  const [shadow, setShadow] = useState("shadow-lg");

  const fetchProfile = () => {
    const profile = getUserProfile();
    setImage(profile.collegeImage || PlaceHolderImages.find(img => img.id === 'college-1')?.imageUrl || null);
    if (profile.collegeShowcaseHeight) setHeight(profile.collegeShowcaseHeight);
    if (profile.collegeShowcaseWidth) setWidth(profile.collegeShowcaseWidth);
    if (profile.blockShadow) setShadow(profile.blockShadow);
  };

  useEffect(() => {
    fetchProfile();
    // Listen for changes from other tabs/windows
    window.addEventListener('storage', fetchProfile);
    return () => {
      window.removeEventListener('storage', fetchProfile);
    };
  }, []);

  const dynamicStyle = {
    height: `${height}px`,
    width: `${width}%`,
    maxWidth: '100%'
  };

  return (
    <div style={dynamicStyle} className="transition-all duration-300 mx-auto">
      <Link href="/upload" className="block h-full w-full">
        <Card className={cn("relative w-full h-full overflow-hidden", shadow)}>
          {image && (
            <Image
              src={image}
              alt="College Showcase"
              fill
              className="object-cover"
              data-ai-hint="college building"
            />
          )}
        </Card>
      </Link>
    </div>
  );
}
