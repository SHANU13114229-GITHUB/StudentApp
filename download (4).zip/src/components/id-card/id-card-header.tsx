// src/components/id-card/id-card-header.tsx
"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { ChevronLeft } from "lucide-react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { getUserProfile } from "@/services/user-profile";

export default function IdCardHeader() {
  const router = useRouter();
  const [logo, setLogo] = useState("/sheat-logo.png");

  const fetchProfile = () => {
    const profile = getUserProfile();
    setLogo(profile.idCardLogo || "/sheat-logo.png");
  };

  useEffect(() => {
    fetchProfile();
    window.addEventListener("storage", fetchProfile);
    return () => {
      window.removeEventListener("storage", fetchProfile);
    };
  }, []);

  return (
    <header className="bg-primary text-primary-foreground p-2 flex items-center justify-between shadow-md">
      <div className="flex items-center">
        <Button
          variant="ghost"
          size="icon"
          className="mr-2 hover:bg-primary/80"
          onClick={() => router.back()}
        >
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-lg font-bold">SHEAT GROUP OF INSTITUTIONS</h1>
      </div>
      <Link href="/id-card/upload-logo">
        <div className="bg-white p-1 rounded-sm cursor-pointer">
          <Image
            src={logo}
            alt="SHEAT Logo"
            width={32}
            height={32}
            className="object-contain"
          />
        </div>
      </Link>
    </header>
  );
}
