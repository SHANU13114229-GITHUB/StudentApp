import { ChevronRight, LayoutGrid, Palette, Text, User, Rows, Grid, Upload, Paintbrush, RefreshCcw, Wallet } from "lucide-react";
import Link from "next/link";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import BottomNav from "@/components/layout/bottom-nav";

const settingsItems = [
    {
        href: "/settings/manage-blocks",
        icon: LayoutGrid,
        title: "Manage Dashboard Blocks",
        description: "Resize and manage gaps for dashboard blocks."
    },
     {
        href: "/settings/manage-quick-access",
        icon: Grid,
        title: "Manage Quick Access Items",
        description: "Show or hide items and adjust spacing."
    },
     {
        href: "/settings/manage-quick-access-colors",
        icon: Palette,
        title: "Manage Quick Access Colors",
        description: "Change the icon color in the Quick Access block."
    },
    {
        href: "/settings/manage-header-text",
        icon: Text,
        title: "Customize Header Text",
        description: "Change the greeting and student name."
    },
    {
        href: "/manage-header",
        icon: Text,
        title: "Manage Header Text Size",
        description: "Change the font size of the header text."
    },
    {
        href: "/settings/manage-header-color",
        icon: Palette,
        title: "Manage Header Color",
        description: "Change the background color of the header."
    },
    {
        href: "/attendance",
        icon: Palette,
        title: "Manage Attendance",
        description: "Change attendance percentages and colors."
    },
    {
        href: "/settings/upload-full-id-card",
        icon: Upload,
        title: "Upload Full ID Card",
        description: "Upload an image of your physical ID card."
    },
    {
        href: "/attendance-image/upload",
        icon: Upload,
        title: "Upload Attendance Image",
        description: "Upload a full-screen attendance image."
    },
    {
        href: "/fees/upload",
        icon: Wallet,
        title: "Upload Fee Receipt",
        description: "Upload an image of your fee receipt."
    },
    {
        href: "/settings/manage-shadows",
        icon: Paintbrush,
        title: "Manage Block Shadows",
        description: "Adjust the shadow intensity of dashboard blocks."
    }
];

export default function SettingsPage() {
  return (
    <div className="flex min-h-screen flex-col bg-gray-100">
        <header className="bg-primary text-primary-foreground p-4 shadow-md">
            <h1 className="text-xl font-bold">Settings</h1>
        </header>
      <main className="flex-grow p-4 pb-20">
        <Card>
          <CardHeader>
            <CardTitle>Appearance & Content</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="divide-y divide-gray-200">
                {settingsItems.map(item => (
                    <li key={item.href}>
                        <Link href={item.href} className="flex items-center justify-between p-4 hover:bg-gray-50">
                            <div className="flex items-center gap-4">
                                <item.icon className="h-6 w-6 text-primary" />
                                <div>
                                    <p className="font-semibold">{item.title}</p>
                                    <p className="text-sm text-gray-500">{item.description}</p>
                                </div>
                            </div>
                            <ChevronRight className="h-5 w-5 text-gray-400" />
                        </Link>
                    </li>
                ))}
            </ul>
          </CardContent>
        </Card>
      </main>
      <BottomNav />
    </div>
  );
}
