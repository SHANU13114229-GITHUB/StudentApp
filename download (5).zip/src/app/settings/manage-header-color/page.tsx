// src/app/settings/manage-header-color/page.tsx
"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Save, Palette } from "lucide-react";
import { getUserProfile, updateUserProfile } from "@/services/user-profile";
import { Skeleton } from "@/components/ui/skeleton";

export default function ManageHeaderColorPage() {
  const [r, setR] = useState(50);
  const [g, setG] = useState(126);
  const [b, setB] = useState(201);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    const profile = getUserProfile();
    if (profile.headerBackgroundColor) {
      setR(profile.headerBackgroundColor.r);
      setG(profile.headerBackgroundColor.g);
      setB(profile.headerBackgroundColor.b);
    }
    setLoading(false);
  }, []);

  const handleSave = () => {
    updateUserProfile({ headerBackgroundColor: { r, g, b } });
    router.push("/");
  };
  
  const colorPreviewStyle = {
      backgroundColor: `rgb(${r}, ${g}, ${b})`,
  };

  if (loading) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-gray-100 p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-center text-2xl font-bold">
              Manage Header Color
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-8">
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gray-100 p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-center text-2xl font-bold">
            Manage Header Color
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-8">
          <div className="space-y-6">
            <div className="flex items-center gap-4">
                <Palette className="h-6 w-6" />
                <div style={colorPreviewStyle} className="h-16 w-full rounded-md border" />
            </div>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label htmlFor="r-slider" className="font-medium text-red-600">
                  Red
                </label>
                <span className="font-bold text-lg text-red-600">{r}</span>
              </div>
              <Slider
                id="r-slider"
                min={0}
                max={255}
                step={1}
                value={[r]}
                onValueChange={(value) => setR(value[0])}
              />
            </div>
             <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label htmlFor="g-slider" className="font-medium text-green-600">
                  Green
                </label>
                <span className="font-bold text-lg text-green-600">{g}</span>
              </div>
              <Slider
                id="g-slider"
                min={0}
                max={255}
                step={1}
                value={[g]}
                onValueChange={(value) => setG(value[0])}
              />
            </div>
             <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label htmlFor="b-slider" className="font-medium text-blue-600">
                  Blue
                </label>
                <span className="font-bold text-lg text-blue-600">{b}</span>
              </div>
              <Slider
                id="b-slider"
                min={0}
                max={255}
                step={1}
                value={[b]}
                onValueChange={(value) => setB(value[0])}
              />
            </div>
          </div>

          <Button onClick={handleSave} className="w-full">
            <Save className="mr-2 h-4 w-4" />
            Save and Go to Home
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
