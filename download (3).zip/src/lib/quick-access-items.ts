// src/lib/quick-access-items.ts
import {
  User,
  CalendarDays,
  Laptop,
  BookText,
  Ticket,
  ClipboardCheck,
  FileText,
  Wallet,
  PlusSquare,
  Award,
  Train,
  FilePlus2,
  Hotel,
  Calendar,
  Star,
  type LucideIcon,
} from "lucide-react";

export type QuickAccessItemConfig = {
  id: string;
  label: string;
  icon: LucideIcon | React.ComponentType<{ className?: string }>;
  href?: string;
};

export const allQuickAccessItems: QuickAccessItemConfig[] = [
  { id: "attendance", label: "Attendance", icon: User, href: "/attendance-image" },
  { id: "class-schedule", label: "Class Schedule", icon: CalendarDays, href: "#" },
  { id: "online-classes", label: "Online Classes", icon: Laptop, href: "#" },
  { id: "exam-timetable", label: "Exam TimeTable", icon: BookText, href: "#" },
  { id: "exam-hallticket", label: "Exam HallTicket", icon: Ticket, href: "#" },
  { id: "result", label: "Result", icon: ClipboardCheck, href: "#" },
  { id: "internal-mark", label: "Internal Mark", icon: FileText, href: "#" },
  { id: "fees-paid", label: "Fees Paid", icon: Wallet, href: "/fees" },
  { id: "register", label: "Register", icon: PlusSquare, href: "#" },
  { id: "certificate", label: "Certificate", icon: Award, href: "#" },
  { id: "railway-concession", label: "Railway Concession", icon: Train, href: "#" },
  { id: "apply-itle", label: "Apply ITLE", icon: FilePlus2, href: "#" },
  { id: "hostel-attendance", label: "Hostel Attendance", icon: Hotel, href: "#" },
  { id: "calendar", label: "Calendar", icon: Calendar, href: "#" },
  { id: "feedback", label: "Feedback", icon: Star, href: "#" },
];
