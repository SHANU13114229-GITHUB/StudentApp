// src/components/layout/bottom-nav.tsx
"use client";

import { Home, MessageSquareText, User, Bell, Settings } from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, useEffect } from "react";
import { getUserProfile } from "@/services/user-profile";
import { cn } from "@/lib/utils";
import { Card } from "../ui/card";

const navItems = [
  { href: "/", label: "Home", icon: Home },
  { href: "#messages", label: "Messages", icon: MessageSquareText },
  { href: "/id-card", label: "ID Card", icon: User },
  { href: "#notifications", label: "Notifications", icon: Bell },
  { href: "/settings", label: "Settings", icon: Settings },
];

export default function BottomNav() {
  const pathname = usePathname();
  const [height, setHeight] = useState(64);
  const [width, setWidth] = useState(100);
  const [bottomGap, setBottomGap] = useState(0);
  const [borderRadius, setBorderRadius] = useState(12);
  const [shadow, setShadow] = useState("shadow-lg");

  const fetchProfile = () => {
    const profile = getUserProfile();
    setHeight(profile.bottomNavHeight ?? 64);
    setWidth(profile.bottomNavWidth ?? 100);
    setBottomGap(profile.bottomNavGap ?? 0);
    setBorderRadius(profile.bottomNavBorderRadius ?? 12);
    setShadow(profile.blockShadow ?? "shadow-lg");
  };

  useEffect(() => {
    fetchProfile();
    // Listen for changes from other tabs/windows
    window.addEventListener('storage', fetchProfile);
    return () => {
      window.removeEventListener('storage', fetchProfile);
    };
  }, []);

  const getIsActive = (href: string) => {
    if (href === "/") {
        return pathname === "/";
    }
    if (href.startsWith("/")){
        return pathname.startsWith(href);
    }
    return false;
  }
  
  const wrapperStyle = {
    bottom: `${bottomGap}px`,
  };
  
  const cardStyle = {
      height: `${height}px`,
      width: `${width}%`,
      borderRadius: `${borderRadius}px`
  }

  return (
    <div style={wrapperStyle} className="fixed bottom-0 left-0 right-0 z-50 transition-all duration-300 pointer-events-none flex justify-center">
        <Card style={cardStyle} className={cn("flex justify-around items-center max-w-lg pointer-events-auto", shadow)}>
            {navItems.map((item) => {
            const isActive = getIsActive(item.href);
            return (
                <Link
                href={item.href}
                key={item.label}
                className="flex flex-col items-center justify-center w-16 h-full text-center"
                >
                <item.icon
                    className={`h-6 w-6 transition-colors ${
                    isActive ? "text-primary" : "text-muted-foreground"
                    }`}
                />
                {isActive && (
                    <span
                    className={`text-xs font-medium transition-colors text-primary`}
                    >
                    {item.label}
                    </span>
                )}
                </Link>
            );
            })}
        </Card>
    </div>
  );
}
