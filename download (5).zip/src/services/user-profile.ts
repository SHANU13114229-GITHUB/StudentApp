// src/services/user-profile.ts
const PROFILE_KEY = "userProfile";

export type UserProfile = {
  headerTextPercentage?: number;
  headerBackgroundColor?: { r: number; g: number; b: number };
  greetingText?: string;
  studentName?: string;
  theoryAttendance?: number;
  practicalAttendance?: number;
  overallAttendance?: number;
  attendanceProgressColorRgb?: { r: number, g: number, b: number };
  logoPadding?: number;
  logoRadius?: number;
  logoBorder?: number;
  logoImage?: string;
  collegeImage?: string;
  chatbotIcon?: string;
  chatbotIconSize?: number;
  collegeShowcaseHeight?: number;
  collegeShowcaseWidth?: number;
  attendanceSummaryHeight?: number;
  attendanceSummaryWidth?: number;
  quickAccessHeight?: number;
  quickAccessWidth?: number;
  bottomNavHeight?: number;
  bottomNavWidth?: number;
  bottomNavGap?: number;
  bottomNavBorderRadius?: number;
  attendanceRowGap?: number;
  attendanceTitleSize?: number;
  attendanceLabelSize?: number;
  attendancePercentageSize?: number;
  attendanceTitleLabel?: string;
  attendanceTheoryLabel?: string;
  attendancePracticalLabel?: string;
  attendanceOverallLabel?: string;
  gapAboveShowcase?: number;
  gapAboveAttendance?: number;
  gapAboveQuickAccess?: number;
  quickAccessItems?: string[];
  fullIdCardImage?: string;
  quickAccessIconColor?: { r: number; g: number; b: number };
  quickAccessHorizontalGap?: number;
  quickAccessVerticalGap?: number;
  fullIdCardHeight?: number;
  fullIdCardWidth?: number;
  blockShadow?: string;
  institutionInfoHeight?: number;
  institutionInfoWidth?: number;
  gapAboveInstitutionInfo?: number;
  feesPaidImage?: string;
  attendanceImage?: string;
};

const defaultProfile: UserProfile = {
  headerTextPercentage: 100,
  headerBackgroundColor: { r: 50, g: 126, b: 201 },
  greetingText: "",
  studentName: "SHANU VISHWAKARMA",
  theoryAttendance: 76,
  practicalAttendance: 85,
  overallAttendance: 80,
  attendanceProgressColorRgb: { r: 74, g: 222, b: 128 },
  logoPadding: 2,
  logoRadius: 0,
  logoBorder: 0,
  logoImage: "/sheat-logo.png",
  collegeImage: "/sheat-eng-mgm.png",
  chatbotIcon: "",
  chatbotIconSize: 100,
  collegeShowcaseHeight: 200,
  collegeShowcaseWidth: 100,
  attendanceSummaryHeight: 110,
  attendanceSummaryWidth: 100,
  quickAccessHeight: 240,
  quickAccessWidth: 100,
  bottomNavHeight: 64,
  bottomNavWidth: 100,
  bottomNavGap: 0,
  bottomNavBorderRadius: 12,
  attendanceRowGap: 4,
  attendanceTitleSize: 100,
  attendanceLabelSize: 100,
  attendancePercentageSize: 100,
  attendanceTitleLabel: "Attendance",
  attendanceTheoryLabel: "Theory",
  attendancePracticalLabel: "Practical",
  attendanceOverallLabel: "Overall",
  gapAboveShowcase: 16,
  gapAboveAttendance: 16,
  gapAboveQuickAccess: 16,
  quickAccessItems: [
    "attendance",
    "class-schedule",
    "online-classes",
    "exam-timetable",
    "exam-hallticket",
    "result",
    "internal-mark",
    "fees-paid",
    "register",
  ],
  fullIdCardImage: null,
  quickAccessIconColor: { r: 50, g: 126, b: 201 },
  quickAccessHorizontalGap: 8,
  quickAccessVerticalGap: 16,
  fullIdCardHeight: 100,
  fullIdCardWidth: 200,
  blockShadow: "shadow-lg",
  institutionInfoHeight: 60,
  institutionInfoWidth: 100,
  gapAboveInstitutionInfo: 16,
  feesPaidImage: null,
  attendanceImage: null,
};

// This function now runs synchronously and only on the client.
export function getUserProfile(): UserProfile {
  if (typeof window === 'undefined') {
    return defaultProfile;
  }
  try {
    const storedProfile = window.localStorage.getItem(PROFILE_KEY);
    if (storedProfile) {
      const parsed = JSON.parse(storedProfile);
      // Ensure default for new properties if profile is old
      return { ...defaultProfile, ...parsed };
    } else {
      window.localStorage.setItem(PROFILE_KEY, JSON.stringify(defaultProfile));
      return defaultProfile;
    }
  } catch (error) {
    console.error("Error getting user profile from localStorage: ", error);
    return defaultProfile;
  }
}

// This function now runs synchronously and only on the client.
export function updateUserProfile(updates: Partial<UserProfile>): void {
  if (typeof window === 'undefined') {
    return;
  }
  try {
    const currentProfile = getUserProfile();
    const newProfile = { ...currentProfile, ...updates };
    window.localStorage.setItem(PROFILE_KEY, JSON.stringify(newProfile));
    
    // Dispatch a storage event to notify other components/tabs of the change.
    window.dispatchEvent(new StorageEvent('storage', {
      key: PROFILE_KEY,
      newValue: JSON.stringify(newProfile),
    }));

  } catch (error) {
    console.error("Error updating user profile in localStorage: ", error);
  }
}
