// src/app/upload-logo/page.tsx
"use client";

import { useState, ChangeEvent, useEffect } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Upload, Square, Radius, BoxSelect } from "lucide-react";
import { Slider } from "@/components/ui/slider";
import { getUserProfile, updateUserProfile } from "@/services/user-profile";
import { Skeleton } from "@/components/ui/skeleton";

export default function UploadLogoPage() {
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [newImage, setNewImage] = useState<string | null>(null);
  const [padding, setPadding] = useState(2);
  const [radius, setRadius] = useState(0);
  const [border, setBorder] = useState(0);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    const profile = getUserProfile();
    if (profile.logoPadding) setPadding(profile.logoPadding);
    if (profile.logoRadius) setRadius(profile.logoRadius);
    if (profile.logoBorder) setBorder(profile.logoBorder);
    if (profile.logoImage) {
      setImagePreview(profile.logoImage);
    } else {
      setImagePreview("/sheat-logo.png");
    }
    setLoading(false);
  }, []);

  const handleImageChange = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setImagePreview(result);
        setNewImage(result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    const updates: { [key: string]: any } = {
      logoPadding: padding,
      logoRadius: radius,
      logoBorder: border,
    };
    if (newImage) {
      updates.logoImage = newImage;
    }
    updateUserProfile(updates);
    router.push("/");
  };
  
  const logoStyle = {
      padding: `${padding}px`,
      borderRadius: `${radius}px`,
      borderWidth: `${border}px`
  };
  
  if (loading) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-gray-100 p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-center text-2xl font-bold">
              Manage Logo
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-24 w-24 mx-auto" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gray-100 p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-center text-2xl font-bold">
            Manage Logo
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <label htmlFor="image-upload" className="font-medium">
              Choose an image
            </label>
            <Input
              id="image-upload"
              type="file"
              accept="image/*"
              onChange={handleImageChange}
            />
          </div>

          {imagePreview && (
            <div className="flex justify-center">
                <div 
                    style={logoStyle}
                    className="relative h-24 w-24 overflow-hidden bg-white border-primary">
                    <Image
                        src={imagePreview}
                        alt="Selected image preview"
                        fill
                        className="object-contain"
                    />
                </div>
            </div>
          )}

          <div className="space-y-4">
            <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                    <BoxSelect className="h-5 w-5" />
                    <label htmlFor="padding-slider" className="font-medium">
                        Padding
                    </label>
                </div>
                <span className="font-bold text-lg text-primary">{padding}px</span>
            </div>
            <Slider
              id="padding-slider"
              min={0}
              max={20}
              step={1}
              value={[padding]}
              onValueChange={(value) => setPadding(value[0])}
            />
          </div>

          <div className="space-y-4">
            <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                    <Radius className="h-5 w-5" />
                    <label htmlFor="radius-slider" className="font-medium">
                        Border Radius
                    </label>
                </div>
                <span className="font-bold text-lg text-primary">{radius}px</span>
            </div>
            <Slider
              id="radius-slider"
              min={0}
              max={50}
              step={1}
              value={[radius]}
              onValueChange={(value) => setRadius(value[0])}
            />
          </div>
          
          <div className="space-y-4">
            <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                    <Square className="h-5 w-5" />
                    <label htmlFor="border-slider" className="font-medium">
                        Border Width
                    </label>
                </div>
                <span className="font-bold text-lg text-primary">{border}px</span>
            </div>
            <Slider
              id="border-slider"
              min={0}
              max={10}
              step={1}
              value={[border]}
              onValueChange={(value) => setBorder(value[0])}
            />
          </div>


          <Button
            onClick={handleSave}
            className="w-full"
          >
            <Upload className="mr-2 h-4 w-4" />
            Save and Go to Home
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
