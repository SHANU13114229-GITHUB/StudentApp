// src/components/dashboard/header.tsx
"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { getUserProfile } from "@/services/user-profile";

// Base font sizes in rem
const baseSizes = {
  greeting: 1.25, // equivalent to text-xl
  name: 1.5,      // equivalent to text-2xl
};

const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good Morning";
    if (hour < 18) return "Good Afternoon";
    return "Good Evening";
}

export default function Header() {
  const [logoSrc, setLogoSrc] = useState("/sheat-logo.png");
  const [sizePercentage, setSizePercentage] = useState(100);
  const [logoStyles, setLogoStyles] = useState<React.CSSProperties>({});
  const [headerStyle, setHeaderStyle] = useState<React.CSSProperties>({});
  const [greeting, setGreeting] = useState("Good Morning");
  const [studentName, setStudentName] = useState("SHANU VISHWAKARMA");


  const fetchProfile = () => {
    const profile = getUserProfile();
    setGreeting(profile.greetingText || getGreeting());
    setStudentName(profile.studentName || "SHANU VISHWAKARMA");
    if (profile.headerTextPercentage) {
      setSizePercentage(profile.headerTextPercentage);
    }
    
    const styles: React.CSSProperties = {};
    if (profile.logoPadding) styles.padding = `${profile.logoPadding}px`;
    if (profile.logoRadius) styles.borderRadius = `${profile.logoRadius}px`;
    if (profile.logoBorder) styles.borderWidth = `${profile.logoBorder}px`;
    if (Object.keys(styles).length > 0) {
        styles.borderColor = 'hsl(var(--primary))';
        styles.backgroundColor = 'white';
    }
    setLogoStyles(styles);

    if (profile.logoImage) {
      setLogoSrc(profile.logoImage);
    }
    
    if (profile.headerBackgroundColor) {
        const {r, g, b} = profile.headerBackgroundColor;
        setHeaderStyle({ backgroundColor: `rgb(${r}, ${g}, ${b})` });
    }
  };

  useEffect(() => {
    fetchProfile();
    // Listen for changes from other tabs/windows
    window.addEventListener('storage', fetchProfile);
    return () => {
      window.removeEventListener('storage', fetchProfile);
    };
  }, []);

  const calculateSize = (base: number) => {
    return `${base * (sizePercentage / 100)}rem`;
  };

  const dynamicStyles = {
    greeting: { fontSize: calculateSize(baseSizes.greeting) },
    name: { fontSize: calculateSize(baseSizes.name) },
  };

  return (
    <header className="text-primary-foreground p-2 shadow-md" style={headerStyle}>
      <div className="flex items-center justify-between">
        <Link href="/manage-header">
          <div>
            <p
              className="text-primary-foreground/80 transition-all"
              style={dynamicStyles.greeting}
            >
              {greeting}
            </p>
            <h1
              className="font-bold transition-all"
              style={dynamicStyles.name}
            >
              {studentName}
            </h1>
          </div>
        </Link>
        <Link href="/upload-logo" className="flex flex-col items-center">
          <div style={logoStyles}>
            <Image
              src={logoSrc}
              alt="SHEAT Logo"
              width={32}
              height={32}
              className="object-contain"
            />
          </div>
          <p className="text-[8px] mt-0.5 text-center max-w-20 font-semibold leading-tight text-primary-foreground/80">
            Learn Today, Lead Tomorrow
          </p>
        </Link>
      </div>
    </header>
  );
}
