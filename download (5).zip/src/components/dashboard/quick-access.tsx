// src/components/dashboard/quick-access.tsx
"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { Card, CardContent } from "../ui/card";
import { getUserProfile } from "@/services/user-profile";
import { allQuickAccessItems, type QuickAccessItemConfig } from "@/lib/quick-access-items";
import { Grid } from "lucide-react";
import { Button } from "../ui/button";
import { cn } from "@/lib/utils";

export default function QuickAccess() {
  const [height, setHeight] = useState(240);
  const [width, setWidth] = useState(100);
  const [items, setItems] = useState<QuickAccessItemConfig[]>([]);
  const [iconColor, setIconColor] = useState({ r: 50, g: 126, b: 201 });
  const [horizontalGap, setHorizontalGap] = useState(8);
  const [verticalGap, setVerticalGap] = useState(16);
  const [shadow, setShadow] = useState("shadow-lg");


  const fetchProfile = () => {
    const profile = getUserProfile();
    if (profile.quickAccessHeight) setHeight(profile.quickAccessHeight);
    if (profile.quickAccessWidth) setWidth(profile.quickAccessWidth);
    if (profile.quickAccessIconColor) setIconColor(profile.quickAccessIconColor);
    if (profile.quickAccessHorizontalGap) setHorizontalGap(profile.quickAccessHorizontalGap);
    if (profile.quickAccessVerticalGap) setVerticalGap(profile.quickAccessVerticalGap);
    if (profile.blockShadow) setShadow(profile.blockShadow);

    const visibleItemIds = new Set(profile.quickAccessItems);
    if (visibleItemIds.size > 0) {
      const visibleItems = allQuickAccessItems.filter(item => visibleItemIds.has(item.id));
      setItems(visibleItems);
    } else {
      // Default to showing some items if none are selected
      setItems(allQuickAccessItems.slice(0,9));
    }
  };

  useEffect(() => {
    fetchProfile();
    // Listen for changes from other tabs/windows
    window.addEventListener('storage', fetchProfile);
    return () => {
      window.removeEventListener('storage', fetchProfile);
    };
  }, []);

  const dynamicStyle = {
    height: `${height}px`,
    width: `${width}%`,
    maxWidth: '100%'
  };
  
  const gridCols = items.length <= 3 ? items.length : (items.length <= 6 ? 3 : (items.length <= 8 ? 4 : 3));
  
  const iconBgStyle = {
    backgroundColor: `rgb(${iconColor.r}, ${iconColor.g}, ${iconColor.b})`,
  };
  
  const gridStyle = {
      gridTemplateColumns: `repeat(${gridCols}, minmax(0, 1fr))`,
      rowGap: `${verticalGap}px`,
      columnGap: `${horizontalGap}px`,
  };


  return (
    <div style={dynamicStyle} className="transition-all duration-300 flex flex-col mx-auto">
       <Card className={cn("p-2 flex-grow flex flex-col", shadow)}>
          
          <CardContent className="p-0 flex-grow flex flex-col justify-center">
             {items.length > 0 ? (
               <div 
                 className="grid"
                 style={gridStyle}
                >
                {items.map((item) => {
                  const content = (
                    <div
                      key={item.label}
                      className="flex flex-col items-center justify-center space-y-1 cursor-pointer group"
                    >
                      <div 
                        style={iconBgStyle}
                        className="p-2 rounded-full group-hover:opacity-90 transition-colors"
                      >
                        <item.icon className="h-6 w-6 text-white" />
                      </div>
                      <p className="text-xs text-center font-medium text-gray-700 group-hover:text-primary">
                        {item.label}
                      </p>
                    </div>
                  );
    
                  if (item.href && item.href !== "#") {
                    return (
                      <Link href={item.href} key={item.label}>
                        {content}
                      </Link>
                    );
                  }
                  return content;
                })}
              </div>
            ) : (
              <div className="text-center text-gray-500">
                 <p>No items to display.</p>
                 <p className="text-sm">
                    Go to{" "}
                    <Link href="/settings/manage-quick-access" className="text-primary underline">
                        Settings
                    </Link>{" "}
                    to add items.
                </p>
              </div>
            )}
          </CardContent>
       </Card>
    </div>
  );
}
