// src/app/attendance-image/page.tsx
"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { ArrowLeft, UserCheck } from "lucide-react";
import { getUserProfile } from "@/services/user-profile";
import { Skeleton } from "@/components/ui/skeleton";
import Link from "next/link";
import { useRouter } from "next/navigation";


export default function ViewAttendanceImagePage() {
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    const profile = getUserProfile();
    setImagePreview(profile.attendanceImage || null);
    setLoading(false);
  }, []);
  
  if (loading) {
    return (
      <div className="flex flex-col h-screen bg-gray-900 text-white justify-center items-center">
        <Skeleton className="w-full h-full bg-gray-800" />
      </div>
    )
  }

  return (
     <div className="flex flex-col h-screen bg-gray-900 text-white">
        <div className="absolute top-4 left-4 z-10">
            <Button variant="ghost" size="icon" onClick={() => router.back()} className="text-white hover:bg-white/20 hover:text-white">
                <ArrowLeft className="h-6 w-6" />
            </Button>
        </div>
      
      <main className="flex-grow flex flex-col overflow-auto">
        <div className="relative w-full h-full flex">
          {imagePreview ? (
            <Image
              src={imagePreview}
              alt="Attendance Image Preview"
              width={1000}
              height={1000}
              loading="lazy"
              className="object-contain w-full h-full"
            />
          ) : (
            <div className="flex flex-col items-center justify-center w-full text-gray-400 text-center p-4">
                <UserCheck className="h-24 w-24 mb-4" />
                <p className="text-lg font-semibold">No Attendance Image Uploaded</p>
                <p className="text-sm">Go to settings to upload your attendance image.</p>
                <Button asChild variant="link" className="mt-4 text-lg">
                    <Link href="/attendance-image/upload">
                        Upload Now
                    </Link>
                </Button>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
