// src/app/manage-header/page.tsx
"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Save, Text } from "lucide-react";
import { getUserProfile, updateUserProfile } from "@/services/user-profile";
import { Skeleton } from "@/components/ui/skeleton";

export default function ManageHeaderPage() {
  const [size, setSize] = useState(100);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    const profile = getUserProfile();
    if (profile.headerTextPercentage) {
      setSize(profile.headerTextPercentage);
    }
    setLoading(false);
  }, []);

  const handleSliderChange = (value: number[]) => {
    setSize(value[0]);
  };

  const handleSave = () => {
    updateUserProfile({ headerTextPercentage: size });
    router.push("/");
  };

  if (loading) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-gray-100 p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-center text-2xl font-bold">
              Manage Header Text Size
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-8">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gray-100 p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-center text-2xl font-bold">
            Manage Header Text Size
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-8">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Text className="h-5 w-5" />
                <label htmlFor="size-slider" className="font-medium">
                  Header Font Size
                </label>
              </div>
              <span className="font-bold text-2xl text-primary">{size}%</span>
            </div>
            <Slider
              id="size-slider"
              min={50}
              max={200}
              step={10}
              value={[size]}
              onValueChange={handleSliderChange}
            />
          </div>

          <Button onClick={handleSave} className="w-full">
            <Save className="mr-2 h-4 w-4" />
            Save and Go to Home
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
