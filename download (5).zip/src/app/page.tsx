// src/app/page.tsx
"use client";

import { useState, useEffect } from "react";
import AttendanceSummary from "@/components/dashboard/attendance-summary";
import CollegeShowcase from "@/components/dashboard/college-showcase";
import Header from "@/components/dashboard/header";
import QuickAccess from "@/components/dashboard/quick-access";
import BottomNav from "@/components/layout/bottom-nav";
import Chatbot from "@/components/chatbot/chatbot";
import { Card } from "@/components/ui/card";
import { getUserProfile } from "@/services/user-profile";
import { cn } from "@/lib/utils";

export default function Home() {
  const [institutionInfoHeight, setInstitutionInfoHeight] = useState(60);
  const [institutionInfoWidth, setInstitutionInfoWidth] = useState(100);
  const [gapInstitutionInfo, setGapInstitutionInfo] = useState(16);
  const [gapShowcase, setGapShowcase] = useState(16);
  const [gapAttendance, setGapAttendance] = useState(16);
  const [gapQuickAccess, setGapQuickAccess] = useState(16);
  const [shadow, setShadow] = useState("shadow-lg");
  const [bottomNavHeight, setBottomNavHeight] = useState(64);
  const [bottomNavGap, setBottomNavGap] = useState(0);

  const fetchProfile = () => {
    const profile = getUserProfile();
    setInstitutionInfoHeight(profile.institutionInfoHeight ?? 60);
    setInstitutionInfoWidth(profile.institutionInfoWidth ?? 100);
    setGapInstitutionInfo(profile.gapAboveInstitutionInfo ?? 16);
    if (profile.gapAboveShowcase) setGapShowcase(profile.gapAboveShowcase);
    if (profile.gapAboveAttendance) setGapAttendance(profile.gapAboveAttendance);
    if (profile.gapAboveQuickAccess) setGapQuickAccess(profile.gapAboveQuickAccess);
    if (profile.blockShadow) setShadow(profile.blockShadow);
    setBottomNavHeight(profile.bottomNavHeight ?? 64);
    setBottomNavGap(profile.bottomNavGap ?? 0);
  };

  useEffect(() => {
    fetchProfile();
    window.addEventListener('storage', fetchProfile);
    return () => {
      window.removeEventListener('storage', fetchProfile);
    };
  }, []);

  const institutionInfoStyle = {
    height: `${institutionInfoHeight}px`,
    width: `${institutionInfoWidth}%`,
    maxWidth: '100%',
    marginTop: `${gapInstitutionInfo - 16}px`
  };

  return (
    <div className="flex flex-col h-screen bg-background">
      <Header />
      <main className="flex-grow overflow-y-auto" style={{ paddingBottom: `${bottomNavHeight + bottomNavGap + 16}px`}}>
        <div className="flex flex-col gap-4 py-4">
          <div style={institutionInfoStyle} className="transition-all duration-300 flex flex-col mx-auto">
            <Card className={cn("text-center p-1 flex-grow flex flex-col justify-center", shadow)}>
              <h2 className="text-lg font-bold text-foreground">
                SHEAT GROUP OF INSTITUTIONS
              </h2>
              <p className="text-xs text-black">2025-2026</p>
            </Card>
          </div>
          <div style={{ marginTop: `${gapShowcase - 16}px` }}>
            <CollegeShowcase />
          </div>
          <div style={{ marginTop: `${gapAttendance - 16}px` }}>
            <AttendanceSummary />
          </div>
          <div style={{ marginTop: `${gapQuickAccess - 16}px` }}>
            <QuickAccess />
          </div>
        </div>
      </main>
      <BottomNav />
      <Chatbot />
    </div>
  );
}
