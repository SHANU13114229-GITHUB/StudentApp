// src/app/settings/manage-blocks/page.tsx
"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Save, Rows, Columns, ArrowRightLeft, ArrowUpDown, Image as ImageIcon, StretchVertical, Building, Navigation, MoveVertical, Radius } from "lucide-react";
import { getUserProfile, updateUserProfile } from "@/services/user-profile";
import { Skeleton } from "@/components/ui/skeleton";

export default function ManageBlocksPage() {
  const [institutionInfoHeight, setInstitutionInfoHeight] = useState(60);
  const [institutionInfoWidth, setInstitutionInfoWidth] = useState(100);
  const [gapInstitutionInfo, setGapInstitutionInfo] = useState(16);
  const [showcaseHeight, setShowcaseHeight] = useState(200);
  const [showcaseWidth, setShowcaseWidth] = useState(100);
  const [attendanceHeight, setAttendanceHeight] = useState(110);
  const [attendanceWidth, setAttendanceWidth] = useState(100);
  const [quickAccessHeight, setQuickAccessHeight] = useState(240);
  const [quickAccessWidth, setQuickAccessWidth] = useState(100);
  const [bottomNavHeight, setBottomNavHeight] = useState(64);
  const [bottomNavWidth, setBottomNavWidth] = useState(100);
  const [bottomNavGap, setBottomNavGap] = useState(0);
  const [bottomNavBorderRadius, setBottomNavBorderRadius] = useState(12);
  const [gapShowcase, setGapShowcase] = useState(16);
  const [gapAttendance, setGapAttendance] = useState(16);
  const [gapQuickAccess, setGapQuickAccess] = useState(16);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    const profile = getUserProfile();
    if (profile.institutionInfoHeight) setInstitutionInfoHeight(profile.institutionInfoHeight);
    if (profile.institutionInfoWidth) setInstitutionInfoWidth(profile.institutionInfoWidth);
    if (profile.gapAboveInstitutionInfo) setGapInstitutionInfo(profile.gapAboveInstitutionInfo);
    if (profile.collegeShowcaseHeight) setShowcaseHeight(profile.collegeShowcaseHeight);
    if (profile.collegeShowcaseWidth) setShowcaseWidth(profile.collegeShowcaseWidth);
    if (profile.attendanceSummaryHeight) setAttendanceHeight(profile.attendanceSummaryHeight);
    if (profile.attendanceSummaryWidth) setAttendanceWidth(profile.attendanceSummaryWidth);
    if (profile.quickAccessHeight) setQuickAccessHeight(profile.quickAccessHeight);
    if (profile.quickAccessWidth) setQuickAccessWidth(profile.quickAccessWidth);
    if (profile.bottomNavHeight) setBottomNavHeight(profile.bottomNavHeight);
    if (profile.bottomNavWidth) setBottomNavWidth(profile.bottomNavWidth);
    if (profile.bottomNavGap) setBottomNavGap(profile.bottomNavGap);
    if (profile.bottomNavBorderRadius) setBottomNavBorderRadius(profile.bottomNavBorderRadius);
    if (profile.gapAboveShowcase) setGapShowcase(profile.gapAboveShowcase);
    if (profile.gapAboveAttendance) setGapAttendance(profile.gapAboveAttendance);
    if (profile.gapAboveQuickAccess) setGapQuickAccess(profile.gapAboveQuickAccess);
    setLoading(false);
  }, []);

  const handleSave = () => {
    updateUserProfile({
      institutionInfoHeight: institutionInfoHeight,
      institutionInfoWidth: institutionInfoWidth,
      gapAboveInstitutionInfo: gapInstitutionInfo,
      collegeShowcaseHeight: showcaseHeight,
      collegeShowcaseWidth: showcaseWidth,
      attendanceSummaryHeight: attendanceHeight,
      attendanceSummaryWidth: attendanceWidth,
      quickAccessHeight: quickAccessHeight,
      quickAccessWidth: quickAccessWidth,
      bottomNavHeight: bottomNavHeight,
      bottomNavWidth: bottomNavWidth,
      bottomNavGap: bottomNavGap,
      bottomNavBorderRadius: bottomNavBorderRadius,
      gapAboveShowcase: gapShowcase,
      gapAboveAttendance: gapAttendance,
      gapAboveQuickAccess: gapQuickAccess,
    });
    router.push("/");
  };

  if (loading) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-gray-100 p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-center text-2xl font-bold">
              Manage Dashboard Blocks
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-8">
            <Skeleton className="h-36 w-full" />
            <Skeleton className="h-36 w-full" />
            <Skeleton className="h-36 w-full" />
            <Skeleton className="h-36 w-full" />
            <Skeleton className="h-10 w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gray-100 p-4 overflow-y-auto">
      <Card className="w-full max-w-md my-4">
        <CardHeader>
          <CardTitle className="text-center text-2xl font-bold">
            Manage Dashboard Blocks
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Institution Info */}
          <div className="space-y-4 rounded-lg border p-4">
            <h3 className="font-medium flex items-center gap-2"><Building className="h-5 w-5" /> Institution Info</h3>
             <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label htmlFor="inst-h-slider" className="font-medium flex items-center gap-2 text-sm">
                  <ArrowUpDown className="h-4 w-4" /> Height
                </label>
                <span className="font-bold text-lg text-primary">{institutionInfoHeight}px</span>
              </div>
              <Slider
                id="inst-h-slider"
                min={40}
                max={150}
                step={5}
                value={[institutionInfoHeight]}
                onValueChange={(value) => setInstitutionInfoHeight(value[0])}
              />
            </div>
             <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label htmlFor="inst-w-slider" className="font-medium flex items-center gap-2 text-sm">
                  <ArrowRightLeft className="h-4 w-4" /> Width
                </label>
                <span className="font-bold text-lg text-primary">{institutionInfoWidth}%</span>
              </div>
              <Slider
                id="inst-w-slider"
                min={50}
                max={100}
                step={1}
                value={[institutionInfoWidth]}
                onValueChange={(value) => setInstitutionInfoWidth(value[0])}
              />
            </div>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label htmlFor="gap-inst-slider" className="font-medium flex items-center gap-2 text-sm">
                  <StretchVertical className="h-4 w-4" /> Gap Above
                </label>
                <span className="font-bold text-lg text-primary">{gapInstitutionInfo}px</span>
              </div>
              <Slider
                id="gap-inst-slider"
                min={0}
                max={40}
                step={2}
                value={[gapInstitutionInfo]}
                onValueChange={(value) => setGapInstitutionInfo(value[0])}
              />
            </div>
          </div>
          {/* College Showcase */}
          <div className="space-y-4 rounded-lg border p-4">
            <h3 className="font-medium flex items-center gap-2"><ImageIcon className="h-5 w-5" /> Image Block</h3>
             <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label htmlFor="showcase-h-slider" className="font-medium flex items-center gap-2 text-sm">
                  <ArrowUpDown className="h-4 w-4" /> Height
                </label>
                <span className="font-bold text-lg text-primary">{showcaseHeight}px</span>
              </div>
              <Slider
                id="showcase-h-slider"
                min={100}
                max={400}
                step={10}
                value={[showcaseHeight]}
                onValueChange={(value) => setShowcaseHeight(value[0])}
              />
            </div>
             <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label htmlFor="showcase-w-slider" className="font-medium flex items-center gap-2 text-sm">
                  <ArrowRightLeft className="h-4 w-4" /> Width
                </label>
                <span className="font-bold text-lg text-primary">{showcaseWidth}%</span>
              </div>
              <Slider
                id="showcase-w-slider"
                min={50}
                max={100}
                step={1}
                value={[showcaseWidth]}
                onValueChange={(value) => setShowcaseWidth(value[0])}
              />
            </div>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label htmlFor="gap-showcase-slider" className="font-medium flex items-center gap-2 text-sm">
                  <StretchVertical className="h-4 w-4" /> Gap Above
                </label>
                <span className="font-bold text-lg text-primary">{gapShowcase}px</span>
              </div>
              <Slider
                id="gap-showcase-slider"
                min={0}
                max={40}
                step={2}
                value={[gapShowcase]}
                onValueChange={(value) => setGapShowcase(value[0])}
              />
            </div>
          </div>
          
          {/* Attendance Summary */}
           <div className="space-y-4 rounded-lg border p-4">
            <h3 className="font-medium flex items-center gap-2"><Columns className="h-5 w-5" /> Attendance Summary</h3>
             <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label htmlFor="attendance-h-slider" className="font-medium flex items-center gap-2 text-sm">
                  <ArrowUpDown className="h-4 w-4" /> Height
                </label>
                <span className="font-bold text-lg text-primary">{attendanceHeight}px</span>
              </div>
              <Slider
                id="attendance-h-slider"
                min={80}
                max={200}
                step={5}
                value={[attendanceHeight]}
                onValueChange={(value) => setAttendanceHeight(value[0])}
              />
            </div>
             <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label htmlFor="attendance-w-slider" className="font-medium flex items-center gap-2 text-sm">
                  <ArrowRightLeft className="h-4 w-4" /> Width
                </label>
                <span className="font-bold text-lg text-primary">{attendanceWidth}%</span>
              </div>
              <Slider
                id="attendance-w-slider"
                min={50}
                max={100}
                step={1}
                value={[attendanceWidth]}
                onValueChange={(value) => setAttendanceWidth(value[0])}
              />
            </div>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label htmlFor="gap-attendance-slider" className="font-medium flex items-center gap-2 text-sm">
                  <StretchVertical className="h-4 w-4" /> Gap Above
                </label>
                <span className="font-bold text-lg text-primary">{gapAttendance}px</span>
              </div>
              <Slider
                id="gap-attendance-slider"
                min={0}
                max={40}
                step={2}
                value={[gapAttendance]}
                onValueChange={(value) => setGapAttendance(value[0])}
              />
            </div>
          </div>

          {/* Quick Access */}
           <div className="space-y-4 rounded-lg border p-4">
            <h3 className="font-medium flex items-center gap-2"><Rows className="h-5 w-5" /> Quick Access</h3>
             <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label htmlFor="qa-h-slider" className="font-medium flex items-center gap-2 text-sm">
                  <ArrowUpDown className="h-4 w-4" /> Height
                </label>
                <span className="font-bold text-lg text-primary">{quickAccessHeight}px</span>
              </div>
              <Slider
                id="qa-h-slider"
                min={150}
                max={400}
                step={10}
                value={[quickAccessHeight]}
                onValueChange={(value) => setQuickAccessHeight(value[0])}
              />
            </div>
             <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label htmlFor="qa-w-slider" className="font-medium flex items-center gap-2 text-sm">
                  <ArrowRightLeft className="h-4 w-4" /> Width
                </label>
                <span className="font-bold text-lg text-primary">{quickAccessWidth}%</span>
              </div>
              <Slider
                id="qa-w-slider"
                min={50}
                max={100}
                step={1}
                value={[quickAccessWidth]}
                onValueChange={(value) => setQuickAccessWidth(value[0])}
              />
            </div>
             <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label htmlFor="gap-qa-slider" className="font-medium flex items-center gap-2 text-sm">
                  <StretchVertical className="h-4 w-4" /> Gap Above
                </label>
                <span className="font-bold text-lg text-primary">{gapQuickAccess}px</span>
              </div>
              <Slider
                id="gap-qa-slider"
                min={0}
                max={40}
                step={2}
                value={[gapQuickAccess]}
                onValueChange={(value) => setGapQuickAccess(value[0])}
              />
            </div>
          </div>
          
          {/* Bottom Nav */}
           <div className="space-y-4 rounded-lg border p-4">
            <h3 className="font-medium flex items-center gap-2"><Navigation className="h-5 w-5" /> Navigation Block</h3>
             <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label htmlFor="nav-h-slider" className="font-medium flex items-center gap-2 text-sm">
                  <ArrowUpDown className="h-4 w-4" /> Height
                </label>
                <span className="font-bold text-lg text-primary">{bottomNavHeight}px</span>
              </div>
              <Slider
                id="nav-h-slider"
                min={50}
                max={150}
                step={1}
                value={[bottomNavHeight]}
                onValueChange={(value) => setBottomNavHeight(value[0])}
              />
            </div>
             <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label htmlFor="nav-w-slider" className="font-medium flex items-center gap-2 text-sm">
                  <ArrowRightLeft className="h-4 w-4" /> Width
                </label>
                <span className="font-bold text-lg text-primary">{bottomNavWidth}%</span>
              </div>
              <Slider
                id="nav-w-slider"
                min={50}
                max={100}
                step={1}
                value={[bottomNavWidth]}
                onValueChange={(value) => setBottomNavWidth(value[0])}
              />
            </div>
             <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label htmlFor="nav-g-slider" className="font-medium flex items-center gap-2 text-sm">
                  <MoveVertical className="h-4 w-4" /> Bottom Gap
                </label>
                <span className="font-bold text-lg text-primary">{bottomNavGap}px</span>
              </div>
              <Slider
                id="nav-g-slider"
                min={0}
                max={40}
                step={2}
                value={[bottomNavGap]}
                onValueChange={(value) => setBottomNavGap(value[0])}
              />
            </div>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label htmlFor="nav-br-slider" className="font-medium flex items-center gap-2 text-sm">
                  <Radius className="h-4 w-4" /> Border Radius
                </label>
                <span className="font-bold text-lg text-primary">{bottomNavBorderRadius}px</span>
              </div>
              <Slider
                id="nav-br-slider"
                min={0}
                max={40}
                step={2}
                value={[bottomNavBorderRadius]}
                onValueChange={(value) => setBottomNavBorderRadius(value[0])}
              />
            </div>
          </div>


          <Button onClick={handleSave} className="w-full">
            <Save className="mr-2 h-4 w-4" />
            Save and Go to Home
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
