// chatbot-support.ts
'use server';

/**
 * @fileOverview A chatbot support AI agent for answering FAQs about college services.
 *
 * - chatBotSupport - A function that handles the chatbot support process.
 * - ChatBotSupportInput - The input type for the chatBotSupport function.
 * - ChatBotSupportOutput - The return type for the chatBotSupport function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ChatBotSupportInputSchema = z.object({
  query: z.string().describe('The user query about college services.'),
});
export type ChatBotSupportInput = z.infer<typeof ChatBotSupportInputSchema>;

const ChatBotSupportOutputSchema = z.object({
  answer: z.string().describe('The answer to the user query.'),
});
export type ChatBotSupportOutput = z.infer<typeof ChatBotSupportOutputSchema>;

export async function chatBotSupport(input: ChatBotSupportInput): Promise<ChatBotSupportOutput> {
  return chatBotSupportFlow(input);
}

const getTimetable = ai.defineTool({
  name: 'getTimetable',
  description: 'Use this tool to get timetable information for a given query.',
  inputSchema: z.object({
    query: z.string().describe('The query related to timetable information.'),
  }),
  outputSchema: z.string(),
}, async (input) => {
  // Placeholder implementation for fetching timetable information
  // In a real application, this would involve querying a database or external API.
  return `Timetable information for ${input.query} will be available soon. Please check back later.`;
});

const getFAQ = ai.defineTool({
  name: 'getFAQ',
  description: 'Use this tool to get answers to frequently asked questions.',
  inputSchema: z.object({
    query: z.string().describe('The frequently asked question.'),
  }),
  outputSchema: z.string(),
}, async (input) => {
  // Placeholder implementation for fetching FAQ answer
  // In a real application, this would involve querying a database or external API.
  return `The answer to your question: ${input.query} is: This is a placeholder answer. Please consult the college website for official FAQs.`;
});

const prompt = ai.definePrompt({
  name: 'chatBotSupportPrompt',
  tools: [getTimetable, getFAQ],
  input: {schema: ChatBotSupportInputSchema},
  output: {schema: ChatBotSupportOutputSchema},
  prompt: `You are a helpful and friendly chatbot assistant for SHEAT Group of Institutions.
  Your goal is to answer user queries about the college.
  If the user asks for timetable information or has a frequently asked question, use the provided tools to answer.
  For other questions, provide a helpful and informative response.

  User query: {{{query}}}`,
});

const chatBotSupportFlow = ai.defineFlow(
  {
    name: 'chatBotSupportFlow',
    inputSchema: ChatBotSupportInputSchema,
    outputSchema: ChatBotSupportOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
