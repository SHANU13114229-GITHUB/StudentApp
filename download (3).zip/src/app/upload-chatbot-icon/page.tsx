// src/app/upload-chatbot-icon/page.tsx
"use client";

import { useState, ChangeEvent, useEffect } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Upload, Bot, Scale } from "lucide-react";
import { getUserProfile, updateUserProfile } from "@/services/user-profile";
import { Skeleton } from "@/components/ui/skeleton";

export default function UploadChatbotIconPage() {
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [newImage, setNewImage] = useState<string | null>(null);
  const [size, setSize] = useState(100);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    const profile = getUserProfile();
    if (profile.chatbotIcon) setImagePreview(profile.chatbotIcon);
    if (profile.chatbotIconSize) setSize(profile.chatbotIconSize);
    setLoading(false);
  }, []);

  const handleImageChange = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setImagePreview(result);
        setNewImage(result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    const updates: { chatbotIconSize: number, chatbotIcon?: string } = {
      chatbotIconSize: size,
    };
    if (newImage) {
      updates.chatbotIcon = newImage;
    }
    updateUserProfile(updates);
    router.push("/");
  };
  
  const iconStyle = {
      width: `${56 * (size / 100)}px`,
      height: `${56 * (size / 100)}px`,
  };

  if (loading) {
      return (
          <div className="flex min-h-screen flex-col items-center justify-center bg-gray-100 p-4">
              <Card className="w-full max-w-md">
                  <CardHeader>
                      <CardTitle className="text-center text-2xl font-bold">
                          Customize Chatbot Icon
                      </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                      <Skeleton className="h-10 w-full" />
                      <Skeleton className="h-24 w-24 mx-auto rounded-full" />
                      <Skeleton className="h-10 w-full" />
                      <Skeleton className="h-10 w-full" />
                  </CardContent>
              </Card>
          </div>
      )
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gray-100 p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-center text-2xl font-bold">
            Customize Chatbot Icon
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <label htmlFor="image-upload" className="font-medium">
              Choose an image
            </label>
            <Input
              id="image-upload"
              type="file"
              accept="image/*"
              onChange={handleImageChange}
            />
          </div>

          <div className="flex justify-center">
            <div 
              style={iconStyle}
              className="relative overflow-hidden rounded-full border-4 border-primary/50 flex items-center justify-center bg-primary text-primary-foreground transition-all">
              {imagePreview ? (
                <Image
                  src={imagePreview}
                  alt="Selected image preview"
                  fill
                  className="object-cover"
                />
              ) : (
                <Bot className="h-1/2 w-1/2" />
              )}
            </div>
          </div>
          
          <div className="space-y-4">
            <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                    <Scale className="h-5 w-5" />
                    <label htmlFor="size-slider" className="font-medium">
                        Icon Size
                    </label>
                </div>
                <span className="font-bold text-2xl text-primary">{size}%</span>
            </div>
            <Slider
              id="size-slider"
              min={50}
              max={150}
              step={10}
              value={[size]}
              onValueChange={(value) => setSize(value[0])}
            />
          </div>

          <Button
            onClick={handleSave}
            className="w-full"
          >
            <Upload className="mr-2 h-4 w-4" />
            Save and Go to Home
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
