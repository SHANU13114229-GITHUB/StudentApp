// src/app/attendance/page.tsx
"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Save, Palette, Ruler, Text, CaseSensitive, Percent, Heading1 } from "lucide-react";
import { getUserProfile, updateUserProfile } from "@/services/user-profile";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";

export default function ManageAttendancePage() {
  const [theory, setTheory] = useState(76);
  const [practical, setPractical] = useState(85);
  const [overall, setOverall] = useState(80);
  const [r, setR] = useState(74);
  const [g, setG] = useState(222);
  const [b, setB] = useState(128);
  const [rowGap, setRowGap] = useState(4);
  const [titleSize, setTitleSize] = useState(100);
  const [labelSize, setLabelSize] = useState(100);
  const [percentageSize, setPercentageSize] = useState(100);
  const [titleLabel, setTitleLabel] = useState("Attendance");
  const [theoryLabel, setTheoryLabel] = useState("Theory");
  const [practicalLabel, setPracticalLabel] = useState("Practical");
  const [overallLabel, setOverallLabel] = useState("Overall");
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    const profile = getUserProfile();
    setTheory(profile.theoryAttendance ?? 76);
    setPractical(profile.practicalAttendance ?? 85);
    setOverall(profile.overallAttendance ?? 80);
    if (profile.attendanceProgressColorRgb) {
        setR(profile.attendanceProgressColorRgb.r);
        setG(profile.attendanceProgressColorRgb.g);
        setB(profile.attendanceProgressColorRgb.b);
    }
    setRowGap(profile.attendanceRowGap ?? 4);
    setTitleSize(profile.attendanceTitleSize ?? 100);
    setLabelSize(profile.attendanceLabelSize ?? 100);
    setPercentageSize(profile.attendancePercentageSize ?? 100);
    setTitleLabel(profile.attendanceTitleLabel ?? "Attendance");
    setTheoryLabel(profile.attendanceTheoryLabel ?? "Theory");
    setPracticalLabel(profile.attendancePracticalLabel ?? "Practical");
    setOverallLabel(profile.attendanceOverallLabel ?? "Overall");
    setLoading(false);
  }, []);

  const handleSave = () => {
    updateUserProfile({
      theoryAttendance: theory,
      practicalAttendance: practical,
      overallAttendance: overall,
      attendanceProgressColorRgb: { r, g, b },
      attendanceRowGap: rowGap,
      attendanceTitleSize: titleSize,
      attendanceLabelSize: labelSize,
      attendancePercentageSize: percentageSize,
      attendanceTitleLabel: titleLabel,
      attendanceTheoryLabel: theoryLabel,
      attendancePracticalLabel: practicalLabel,
      attendanceOverallLabel: overallLabel,
    });
    router.push("/");
  };
  
  const colorPreviewStyle = {
      backgroundColor: `rgb(${r}, ${g}, ${b})`,
  };

  if (loading) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-gray-100 p-4">
        <Card className="w-full max-w-lg">
          <CardHeader>
            <CardTitle className="text-center text-2xl font-bold">
              Manage Attendance
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-8">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gray-100 p-4">
      <Card className="w-full max-w-lg">
        <CardHeader>
          <CardTitle className="text-center text-2xl font-bold">
            Manage Attendance
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Percentages */}
          <div className="space-y-4 rounded-lg border p-4">
             <h3 className="font-medium flex items-center gap-2 text-lg"><Percent className="h-5 w-5" /> Percentages</h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label htmlFor="theory-slider" className="font-medium">
                  {theoryLabel}
                </label>
                <span className="font-bold text-2xl text-primary">{theory.toFixed(1)} %</span>
              </div>
              <Slider
                id="theory-slider"
                min={0}
                max={100}
                step={0.1}
                value={[theory]}
                onValueChange={(value) => setTheory(value[0])}
              />
            </div>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label htmlFor="practical-slider" className="font-medium">
                  {practicalLabel}
                </label>
                <span className="font-bold text-2xl text-primary">{practical.toFixed(1)} %</span>
              </div>
              <Slider
                id="practical-slider"
                min={0}
                max={100}
                step={0.1}
                value={[practical]}
                onValueChange={(value) => setPractical(value[0])}
              />
            </div>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label htmlFor="overall-slider" className="font-medium">
                  {overallLabel}
                </label>
                <span className="font-bold text-2xl text-primary">{overall.toFixed(1)} %</span>
              </div>
              <Slider
                id="overall-slider"
                min={0}
                max={100}
                step={0.1}
                value={[overall]}
                onValueChange={(value) => setOverall(value[0])}
              />
            </div>
          </div>
          
          <Separator />

          {/* Labels */}
          <div className="space-y-4 rounded-lg border p-4">
            <h3 className="font-medium flex items-center gap-2 text-lg"><CaseSensitive className="h-5 w-5" /> Text Labels</h3>
            <div className="space-y-2">
              <Label htmlFor="title-label-input">Card Title</Label>
              <Input id="title-label-input" value={titleLabel} onChange={(e) => setTitleLabel(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="theory-label-input">Theory Label</Label>
              <Input id="theory-label-input" value={theoryLabel} onChange={(e) => setTheoryLabel(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="practical-label-input">Practical Label</Label>
              <Input id="practical-label-input" value={practicalLabel} onChange={(e) => setPracticalLabel(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="overall-label-input">Overall Label</Label>
              <Input id="overall-label-input" value={overallLabel} onChange={(e) => setOverallLabel(e.target.value)} />
            </div>
          </div>
          
          <Separator />
          
          {/* Sizing and Gaps */}
          <div className="space-y-4 rounded-lg border p-4">
            <h3 className="font-medium flex items-center gap-2 text-lg"><Text className="h-5 w-5" /> Sizing & Gaps</h3>
             <div className="space-y-4">
              <div className="flex justify-between items-center">
                 <label htmlFor="row-gap-slider" className="font-medium flex items-center gap-2">
                  <Ruler className="h-5 w-5" /> Row Gap
                </label>
                <span className="font-bold text-xl text-primary">{rowGap}px</span>
              </div>
              <Slider
                id="row-gap-slider"
                min={0}
                max={24}
                step={1}
                value={[rowGap]}
                onValueChange={(value) => setRowGap(value[0])}
              />
            </div>
             <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label htmlFor="title-size-slider" className="font-medium flex items-center gap-2">
                  <Heading1 className="h-5 w-5" /> Title Size
                </label>
                <span className="font-bold text-xl text-primary">{titleSize}%</span>
              </div>
              <Slider
                id="title-size-slider"
                min={50}
                max={150}
                step={10}
                value={[titleSize]}
                onValueChange={(value) => setTitleSize(value[0])}
              />
            </div>
             <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label htmlFor="label-size-slider" className="font-medium flex items-center gap-2">
                  <CaseSensitive className="h-5 w-5" /> Label Size
                </label>
                <span className="font-bold text-xl text-primary">{labelSize}%</span>
              </div>
              <Slider
                id="label-size-slider"
                min={50}
                max={150}
                step={10}
                value={[labelSize]}
                onValueChange={(value) => setLabelSize(value[0])}
              />
            </div>
             <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label htmlFor="percentage-size-slider" className="font-medium flex items-center gap-2">
                  <Percent className="h-5 w-5" /> Percentage Size
                </label>
                <span className="font-bold text-xl text-primary">{percentageSize}%</span>
              </div>
              <Slider
                id="percentage-size-slider"
                min={50}
                max={150}
                step={10}
                value={[percentageSize]}
                onValueChange={(value) => setPercentageSize(value[0])}
              />
            </div>
          </div>

          <Separator />

          {/* Color */}
          <div className="space-y-4 rounded-lg border p-4">
             <h3 className="font-medium flex items-center gap-2 text-lg"><Palette className="h-5 w-5" /> Progress Bar Color</h3>
            <div className="flex items-center gap-4">
                <div style={colorPreviewStyle} className="h-10 w-full rounded-md border" />
            </div>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label htmlFor="r-slider" className="font-medium text-red-600">
                  Red
                </label>
                <span className="font-bold text-lg text-red-600">{r}</span>
              </div>
              <Slider
                id="r-slider"
                min={0}
                max={255}
                step={1}
                value={[r]}
                onValueChange={(value) => setR(value[0])}
              />
            </div>
             <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label htmlFor="g-slider" className="font-medium text-green-600">
                  Green
                </label>
                <span className="font-bold text-lg text-green-600">{g}</span>
              </div>
              <Slider
                id="g-slider"
                min={0}
                max={255}
                step={1}
                value={[g]}
                onValueChange={(value) => setG(value[0])}
              />
            </div>
             <div className="space-y-4">
              <div className="flex justify-between items-center">
                <label htmlFor="b-slider" className="font-medium text-blue-600">
                  Blue
                </label>
                <span className="font-bold text-lg text-blue-600">{b}</span>
              </div>
              <Slider
                id="b-slider"
                min={0}
                max={255}
                step={1}
                value={[b]}
                onValueChange={(value) => setB(value[0])}
              />
            </div>
          </div>

          <Button onClick={handleSave} className="w-full h-12 text-lg">
            <Save className="mr-2 h-5 w-5" />
            Save and Go to Home
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
