// src/app/settings/manage-quick-access/page.tsx
"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Save, MoveHorizontal, MoveVertical } from "lucide-react";
import { getUserProfile, updateUserProfile } from "@/services/user-profile";
import { Skeleton } from "@/components/ui/skeleton";
import { allQuickAccessItems } from "@/lib/quick-access-items";
import { Separator } from "@/components/ui/separator";

export default function ManageQuickAccessPage() {
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [horizontalGap, setHorizontalGap] = useState(8);
  const [verticalGap, setVerticalGap] = useState(16);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    const profile = getUserProfile();
    setSelectedItems(profile.quickAccessItems || []);
    if (profile.quickAccessHorizontalGap) setHorizontalGap(profile.quickAccessHorizontalGap);
    if (profile.quickAccessVerticalGap) setVerticalGap(profile.quickAccessVerticalGap);
    setLoading(false);
  }, []);

  const handleCheckboxChange = (itemId: string, checked: boolean) => {
    setSelectedItems((prev) =>
      checked ? [...prev, itemId] : prev.filter((id) => id !== itemId)
    );
  };

  const handleSave = () => {
    updateUserProfile({ 
        quickAccessItems: selectedItems,
        quickAccessHorizontalGap: horizontalGap,
        quickAccessVerticalGap: verticalGap,
    });
    router.push("/");
  };

  if (loading) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-gray-100 p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-center text-2xl font-bold">
              Manage Quick Access Items
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {Array.from({ length: 9 }).map((_, i) => (
                <div key={i} className="flex items-center gap-4">
                    <Skeleton className="h-5 w-5" />
                    <Skeleton className="h-5 w-32" />
                </div>
            ))}
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gray-100 p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-center text-2xl font-bold">
            Manage Quick Access Items
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Select the items you want to see in the Quick Access block on your dashboard.
            </p>
            <div className="grid grid-cols-2 gap-4">
                {allQuickAccessItems.map((item) => (
                <div key={item.id} className="flex items-center space-x-2">
                    <Checkbox
                        id={item.id}
                        checked={selectedItems.includes(item.id)}
                        onCheckedChange={(checked) => handleCheckboxChange(item.id, !!checked)}
                    />
                    <Label htmlFor={item.id} className="flex items-center gap-2 cursor-pointer">
                        <item.icon className="h-5 w-5 text-primary" />
                        {item.label}
                    </Label>
                </div>
                ))}
            </div>
          </div>
          
          <Separator />
          
          <div className="space-y-6">
            <div className="space-y-4">
                <div className="flex justify-between items-center">
                    <label htmlFor="qa-h-gap-slider" className="font-medium flex items-center gap-2 text-sm">
                    <MoveHorizontal className="h-4 w-4" /> Icon Horizontal Gap
                    </label>
                    <span className="font-bold text-lg text-primary">{horizontalGap}px</span>
                </div>
                <Slider
                    id="qa-h-gap-slider"
                    min={0}
                    max={32}
                    step={1}
                    value={[horizontalGap]}
                    onValueChange={(value) => setHorizontalGap(value[0])}
                />
                </div>
                <div className="space-y-4">
                <div className="flex justify-between items-center">
                    <label htmlFor="qa-v-gap-slider" className="font-medium flex items-center gap-2 text-sm">
                    <MoveVertical className="h-4 w-4" /> Icon Vertical Gap
                    </label>
                    <span className="font-bold text-lg text-primary">{verticalGap}px</span>
                </div>
                <Slider
                    id="qa-v-gap-slider"
                    min={0}
                    max={32}
                    step={1}
                    value={[verticalGap]}
                    onValueChange={(value) => setVerticalGap(value[0])}
                />
                </div>
          </div>


          <Button onClick={handleSave} className="w-full">
            <Save className="mr-2 h-4 w-4" />
            Save and Go to Home
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
