export const firebaseConfig = {
  "projectId": "studio-3040978706-d3642",
  "appId": "1:1055711592078:web:06d3cdd4351b9e68b753df",
  "apiKey": "AIzaSyDttMi1NnWvyIBv-e5WlS7eT6SS-0xILLI",
  "authDomain": "studio-3040978706-d3642.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "1055711592078"
};
