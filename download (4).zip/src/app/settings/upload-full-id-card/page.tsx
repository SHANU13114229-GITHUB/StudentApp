// src/app/settings/upload-full-id-card/page.tsx
"use client";

import { useState, ChangeEvent, useEffect } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Upload, User, Save, ArrowUpDown, ArrowRightLeft } from "lucide-react";
import { getUserProfile, updateUserProfile } from "@/services/user-profile";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { Slider } from "@/components/ui/slider";
import { Separator } from "@/components/ui/separator";


export default function UploadFullIdCardSettingsPage() {
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [newImage, setNewImage] = useState<string | null>(null);
  const [height, setHeight] = useState(100);
  const [width, setWidth] = useState(100);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const { toast } = useToast();

  useEffect(() => {
    const profile = getUserProfile();
    setImagePreview(profile.fullIdCardImage || null);
    setHeight(profile.fullIdCardHeight || 100);
    setWidth(profile.fullIdCardWidth || 100);
    setLoading(false);
  }, []);

  const handleImageChange = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setImagePreview(result);
        setNewImage(result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    const updates: any = {
        fullIdCardHeight: height,
        fullIdCardWidth: width,
    };
    if (newImage) {
      updates.fullIdCardImage = newImage;
    }
    updateUserProfile(updates);
    setNewImage(null); // Clear new image after saving
    toast({
        title: "Success!",
        description: "Your ID card settings have been updated.",
    });
    router.push("/id-card");
  };
  
  const triggerFileInput = () => {
    document.getElementById('image-upload')?.click();
  }

  const imageContainerStyle: React.CSSProperties = {
    height: `calc(15rem * ${height / 100})`, // Base height of 15rem (240px)
    width: `calc(100% * ${width / 100})`,
    maxWidth: '100%',
  };

  if (loading) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-gray-100 p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-center text-2xl font-bold">
                Upload Full ID Card
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <Skeleton className="aspect-[9/15] w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
     <div className="flex min-h-screen flex-col items-center justify-center bg-gray-100 p-4">
        <Card className="w-full max-w-md">
            <CardHeader>
                <CardTitle className="text-center text-2xl font-bold">
                    Upload & Resize ID Card
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <div 
                    style={imageContainerStyle}
                    className="relative mx-auto rounded-lg border-2 border-dashed bg-gray-200 flex items-center justify-center transition-all duration-300">
                {imagePreview ? (
                    <Image
                    src={imagePreview}
                    alt="ID Card Preview"
                    fill
                    className="object-contain p-2"
                    />
                ) : (
                    <div className="flex flex-col items-center text-gray-500">
                        <User className="h-16 w-16" />
                        <p>No ID Card uploaded</p>
                    </div>
                )}
                </div>

                <Input
                    id="image-upload"
                    type="file"
                    accept="image/*"
                    onChange={handleImageChange}
                    className="hidden"
                />
                
                <Button
                    onClick={triggerFileInput}
                    variant="outline"
                    className="w-full"
                >
                    <Upload className="mr-2 h-4 w-4" />
                    {imagePreview ? "Change ID Card Image" : "Upload ID Card"}
                </Button>
                
                <Separator />
                
                <div className="space-y-4 rounded-lg border p-4">
                    <h3 className="font-medium flex items-center gap-2 text-lg">Dimensions</h3>
                    <div className="space-y-4">
                        <div className="flex justify-between items-center">
                            <label htmlFor="height-slider" className="font-medium flex items-center gap-2 text-sm">
                            <ArrowUpDown className="h-4 w-4" /> Height
                            </label>
                            <span className="font-bold text-lg text-primary">{height}%</span>
                        </div>
                        <Slider
                            id="height-slider"
                            min={50}
                            max={200}
                            step={5}
                            value={[height]}
                            onValueChange={(value) => setHeight(value[0])}
                        />
                    </div>
                    <div className="space-y-4">
                        <div className="flex justify-between items-center">
                            <label htmlFor="width-slider" className="font-medium flex items-center gap-2 text-sm">
                            <ArrowRightLeft className="h-4 w-4" /> Width
                            </label>
                            <span className="font-bold text-lg text-primary">{width}%</span>
                        </div>
                        <Slider
                            id="width-slider"
                            min={50}
                            max={200}
                            step={1}
                            value={[width]}
                            onValueChange={(value) => setWidth(value[0])}
                        />
                    </div>
                </div>

                <Button
                    onClick={handleSave}
                    className="w-full h-12 text-lg"
                >
                    <Save className="mr-2 h-5 w-5" />
                    Save and View
                </Button>

            </CardContent>
        </Card>
    </div>
  );
}
