// src/components/dashboard/attendance-summary.tsx
"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { getUserProfile } from "@/services/user-profile";
import { cn } from "@/lib/utils";

// Base font sizes in rem
const baseTitleSize = 0.875; // text-sm
const baseLabelSize = 0.75; // text-xs
const basePercentageSize = 0.75; // text-xs

export default function AttendanceSummary() {
  const [theoryAttendance, setTheoryAttendance] = useState(76);
  const [practicalAttendance, setPracticalAttendance] = useState(85);
  const [overallAttendance, setOverallAttendance] = useState(80);
  const [progressColor, setProgressColor] = useState({ r: 74, g: 222, b: 128 });
  const [height, setHeight] = useState(110);
  const [width, setWidth] = useState(100);
  const [rowGap, setRowGap] = useState(4);
  const [titleSize, setTitleSize] = useState(100);
  const [labelSize, setLabelSize] = useState(100);
  const [percentageSize, setPercentageSize] = useState(100);
  const [titleLabel, setTitleLabel] = useState("Attendance");
  const [theoryLabel, setTheoryLabel] = useState("Theory");
  const [practicalLabel, setPracticalLabel] = useState("Practical");
  const [overallLabel, setOverallLabel] = useState("Overall");
  const [shadow, setShadow] = useState("shadow-lg");

  const fetchProfile = () => {
    const profile = getUserProfile();
    setTheoryAttendance(profile.theoryAttendance ?? 76);
    setPracticalAttendance(profile.practicalAttendance ?? 85);
    setOverallAttendance(profile.overallAttendance ?? 80);
    setProgressColor(profile.attendanceProgressColorRgb ?? { r: 74, g: 222, b: 128 });
    if (profile.attendanceSummaryHeight) setHeight(profile.attendanceSummaryHeight);
    if (profile.attendanceSummaryWidth) setWidth(profile.attendanceSummaryWidth);
    if (profile.attendanceRowGap) setRowGap(profile.attendanceRowGap);
    
    setTitleSize(profile.attendanceTitleSize ?? 100);
    setLabelSize(profile.attendanceLabelSize ?? 100);
    setPercentageSize(profile.attendancePercentageSize ?? 100);
    
    setTitleLabel(profile.attendanceTitleLabel ?? "Attendance");
    setTheoryLabel(profile.attendanceTheoryLabel ?? "Theory");
    setPracticalLabel(profile.attendancePracticalLabel ?? "Practical");
    setOverallLabel(profile.attendanceOverallLabel ?? "Overall");
    if (profile.blockShadow) setShadow(profile.blockShadow);
  };

  useEffect(() => {
    fetchProfile();
    // Listen for changes from other tabs/windows
    window.addEventListener('storage', fetchProfile);
    return () => {
      window.removeEventListener('storage', fetchProfile);
    };
  }, []);

  const dynamicStyle = {
    height: `${height}px`,
    width: `${width}%`,
    maxWidth: '100%'
  };
  
  const contentStyle = {
      gap: `${rowGap}px`
  };
  
  const titleStyle = { fontSize: `${baseTitleSize * (titleSize / 100)}rem` };
  const labelStyle = { fontSize: `${baseLabelSize * (labelSize / 100)}rem` };
  const percentageStyle = { fontSize: `${basePercentageSize * (percentageSize / 100)}rem` };

  const colorStyle = {
    backgroundColor: `rgb(${progressColor.r}, ${progressColor.g}, ${progressColor.b})`,
  };
  
  const percentageStyleWithColor = {
    ...percentageStyle,
    color: `rgb(${progressColor.r}, ${progressColor.g}, ${progressColor.b})`,
  };

  return (
    <div style={dynamicStyle} className="transition-all duration-300 flex flex-col mx-auto">
      <Card className={cn("h-full flex flex-col", shadow)}>
        <CardHeader className="flex flex-row items-center justify-between p-2">
          <Link href="/attendance" className="w-full">
            <CardTitle style={titleStyle} className="font-bold w-full text-center">
              {titleLabel}
            </CardTitle>
          </Link>
        </CardHeader>
        <CardContent style={contentStyle} className="flex flex-col p-2 pt-0 flex-grow justify-center">
          <Link href="/attendance" className="space-y-1">
            <div className="flex items-center justify-between">
              <span style={labelStyle} className="font-medium w-20">{theoryLabel}</span>
              <Progress value={theoryAttendance} indicatorStyle={colorStyle} className="flex-1 h-1.5" />
              <span style={percentageStyleWithColor} className={"font-semibold w-16 text-right"}>
                {theoryAttendance.toFixed(1)} %
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span style={labelStyle} className="font-medium w-20">{practicalLabel}</span>
              <Progress value={practicalAttendance} indicatorStyle={colorStyle} className="flex-1 h-1.5" />
              <span style={percentageStyleWithColor} className={"font-semibold w-16 text-right"}>
                {practicalAttendance.toFixed(1)} %
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span style={labelStyle} className="font-medium w-20">{overallLabel}</span>
              <Progress value={overallAttendance} indicatorStyle={colorStyle} className="flex-1 h-1.5" />
              <span style-={percentageStyleWithColor} className={"font-semibold w-16 text-right"} style={percentageStyleWithColor}>
                {overallAttendance.toFixed(1)} %
              </span>
            </div>
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}
